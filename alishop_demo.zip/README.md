AliShop — Daraz-connected demo (One-page Next.js)
================================================
What this is
-------------
- A simple Next.js demo storefront (AliShop) for Clothes.
- Demo frontend (pages/index.jsx) + example server API routes under pages/api/daraz/.
- **Does NOT** contain any App Secret or seller tokens. You must set those as environment variables.

Quick start (local)
-------------------
1. Install: `npm install`
2. Add environment variables in `.env.local` (create file):
   DARAZ_APP_KEY=504482
   DARAZ_APP_SECRET=YOUR_APP_SECRET_HERE
   DARAZ_REDIRECT_URI=http://localhost:3000/api/daraz/oauth-callback
   # (Optional for demo) DARAZ_SELLER_TOKEN=YOUR_SELLER_ACCESS_TOKEN
3. Run dev: `npm run dev`
4. Open: http://localhost:3000

Deploy on Vercel (recommended)
------------------------------
1. Push this repo to GitHub.
2. Import project in Vercel and set the same environment variables in the Vercel dashboard (Project Settings → Environment Variables).
3. Deploy. Use real DARAZ_REDIRECT_URI in Daraz Console (your Vercel URL + /api/daraz/oauth-callback).

Files included
--------------
- pages/index.jsx         (frontend)
- pages/api/daraz/auth.js
- pages/api/daraz/oauth-callback.js
- pages/api/daraz/create-order.js
- pages/api/daraz/status.js
- pages/api/daraz/webhook.js
- package.json
- README.md

Security notes
--------------
- Never commit DARAZ_APP_SECRET or DARAZ_SELLER_TOKEN to Git.
- Use .env.local for local testing and Vercel Environment Variables for deployment.
