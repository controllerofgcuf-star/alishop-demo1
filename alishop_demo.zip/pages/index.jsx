import React, {useState, useEffect} from 'react';

export default function AliShopDemo() {
  const [products,setProducts] = useState([]);
  const [cart,setCart] = useState([]);
  const [msg,setMsg] = useState('');
  const [connected,setConnected] = useState(false);

  useEffect(()=>{
    setProducts([
      {id:'c1', title:'Classic White Shirt', price:2499, sku:'AS-WH-S'},
      {id:'c2', title:'Blue Denim Jacket', price:4599, sku:'AS-DJ-M'},
      {id:'c3', title:'Casual Polo T-Shirt', price:1299, sku:'AS-POLO-L'}
    ]);

    fetch('/api/daraz/status').then(r=>r.json()).then(j=>{ if(j.connected) setConnected(true); }).catch(()=>{});
  },[]);

  function addToCart(p){ setCart(prev=>[...prev,p]); }
  function removeFromCart(i){ setCart(prev=> prev.filter((_,idx)=>idx!==i)); }

  async function placeOrder(){
    if(cart.length===0) return setMsg('Cart is empty');
    setMsg('Placing order...');
    try{
      const res = await fetch('/api/daraz/create-order', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ items: cart, customer: { name: 'Test Buyer', phone: '03000000000', address: 'House #, Street, Faisalabad' } })
      });
      const j = await res.json();
      if(res.ok) setMsg('Order sent to Daraz (id: '+j.order_id+')');
      else setMsg('Error: '+ (j.error || JSON.stringify(j)) );
    }catch(err){ setMsg('Network error: '+err.message); }
  }

  return (
    <div style={{maxWidth:800, margin:'20px auto', fontFamily:'system-ui, -apple-system'}}>
      <header style={{marginBottom:20}}>
        <h1 style={{fontSize:28}}>AliShop — Clothes (Demo)</h1>
        <p style={{color:'#555'}}>Simple demo storefront connected to Daraz (for test orders).</p>
        <div style={{marginTop:12}}>
          <a href="/api/daraz/auth" style={{display:'inline-block', padding:'8px 12px', background:'#2563eb', color:'#fff', borderRadius:6, textDecoration:'none'}}>{connected ? 'Connected to Daraz' : 'Connect Daraz'}</a>
        </div>
      </header>

      <main style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12}}>
        {products.map(p=> (
          <div key={p.id} style={{padding:12, border:'1px solid #ddd', borderRadius:8}}>
            <h3 style={{fontWeight:600}}>{p.title}</h3>
            <p style={{fontSize:12}}>SKU: {p.sku}</p>
            <p style={{fontSize:18, fontWeight:600, marginTop:8}}>Rs. {p.price}</p>
            <button onClick={()=>addToCart(p)} style={{marginTop:10, padding:'8px 10px', background:'#16a34a', color:'#fff', borderRadius:6}}>Add to Cart</button>
          </div>
        ))}
      </main>

      <aside style={{marginTop:20, padding:12, border:'1px solid #eee', borderRadius:8}}>
        <h2 style={{fontWeight:600}}>Cart</h2>
        <ul>
          {cart.map((c,i)=>(
            <li key={i} style={{display:'flex', justifyContent:'space-between', padding:'6px 0'}}>
              <span>{c.title} — Rs. {c.price}</span>
              <button onClick={()=>removeFromCart(i)} style={{color:'#b91c1c', background:'none', border:'none'}}>Remove</button>
            </li>
          ))}
        </ul>
        <div style={{marginTop:12}}>
          <button onClick={placeOrder} style={{padding:'10px 14px', background:'#4f46e5', color:'#fff', borderRadius:6}}>Place Order (via Daraz)</button>
        </div>
        <p style={{marginTop:8, color:'#374151'}}>{msg}</p>
      </aside>

      <footer style={{marginTop:20, fontSize:12, color:'#6b7280'}}>Demo: Implement Daraz signing & order payload server-side before using in production.</footer>
    </div>
  );
}
